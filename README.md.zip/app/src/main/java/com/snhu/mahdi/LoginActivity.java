package com.snhu.mahdi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.util.Base64;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import android.widget.TextView;

import com.github.mahdi.snhu.cs360.finalprojest.R;

public class LoginActivity extends AppCompatActivity {

    private InventoryDatabase mInventoryDb;
    private final String TAG = "LoginActivity.java";

    private EditText mUsernameField;
    private EditText mPasswordField;
    private TextView mErrorText;
    private boolean mUsernameEntered;
    private boolean mPasswordEntered;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // UI elements Initialization
        mUsernameField = findViewById(R.id.usernameBox);
        mPasswordField = findViewById(R.id.passBox);
        mErrorText = findViewById(R.id.msgCenter);
        mInventoryDb = InventoryDatabase.getInstance(getApplicationContext());
        mErrorText.setText("");
        mErrorText.setVisibility(View.INVISIBLE);


    }

    public void onLoginClick(View view) {
        // Clean up username and password by removing spaces
        String username = mUsernameField.getText().toString().trim();
        String password = mPasswordField.getText().toString().trim();

        if (username.length() > 0 && password.length() > 0) {
            try {
                User user = mInventoryDb.UserInfo().getUser(username);
                String hashedPass = hashPassword(password);
                if (user.getPassword().equals(hashedPass)) {
                    Intent intent = new Intent(this, InventoryActivity.class);
                    intent.putExtra(InventoryActivity.EXTRA_USER_ID, username);
                    startActivity(intent);
                } else {
                    mErrorText.setText(getString(R.string.invalidUserOrPassword));
                    mErrorText.setVisibility(View.VISIBLE);
                }
            } catch(Exception e) {
                mErrorText.setText(getString(R.string.loginError));
                mErrorText.setVisibility(View.VISIBLE);
                Log.e(TAG, e.getMessage());
            }

        } else {
            // when wither or both are left empty
            mErrorText.setText(getString(R.string.enterUsernameAndPasswordPrompt));
            mErrorText.setVisibility(View.VISIBLE);
        }
    }

    public void clickAccountCreator(View view) throws UnsupportedEncodingException, NoSuchAlgorithmException {
        String username = mUsernameField.getText().toString().trim();
        String password = mPasswordField.getText().toString().trim();
        // minimum characters for username and password
        if (username.length() > 5 && password.length() > 6) {
            String hashedPass = hashPassword(password);
            User user = new User(username, hashedPass);
            try {
                mInventoryDb.UserInfo().addUser(user);
            } catch (Exception e) {
                mErrorText.setText(getString(R.string.usernameAlreadyExists, username));
                mErrorText.setVisibility(View.VISIBLE);
            }

        } else {
            mErrorText.setText(getString(R.string.enterUsernameAndPasswordPrompt));
            mErrorText.setVisibility(View.VISIBLE);
        }
    }

    private String hashPassword(String password) throws NoSuchAlgorithmException,
            UnsupportedEncodingException {
        MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        byte[] hashInput = password.getBytes("UTF-8");
        byte[] hashOutput = messageDigest.digest(hashInput);
        String hashedPass = Base64.encodeToString(hashOutput, Base64.DEFAULT).toLowerCase();
        return hashedPass;
    }
}