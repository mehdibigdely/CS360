package com.snhu.mahdi;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface ProductInventory {

    @Query("SELECT * FROM inventoryItems WHERE name = :itemName AND user = :userName")
    public InventoryItem getInventoryItem(String itemName, String userName);

    @Query("SELECT * FROM inventoryItems WHERE id = :id")
    public InventoryItem getInventoryItem(long id);

    @Query("SELECT * FROM inventoryItems WHERE user = :user")
    public List<InventoryItem> getInventoryItems(String user);

    @Query("SELECT * FROM inventoryItems WHERE user = :user ORDER BY updated DESC")
    public List<InventoryItem> getInventoryItemsNewerFirst(String user);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public long insertInventoryItem(InventoryItem inventoryItem);

    @Update
    public void updateInventoryItem(InventoryItem inventoryItem);

    @Delete
    public void deleteInventoryItem(InventoryItem inventoryItem);
}