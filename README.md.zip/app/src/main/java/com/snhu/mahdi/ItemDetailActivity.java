package com.snhu.mahdi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.github.mahdi.snhu.cs360.finalprojest.R;

public class ItemDetailActivity extends AppCompatActivity {

    public static final String EXTRA_ITEM_ID = "com.snhu.finalprojectmahdi.EXTRA_ITEM";
    public static final String EXTRA_USERNAME = "com.snhu.finalprojectmahdi.EXTRA_USERNAME";
    private static final String SMS_NUMBER = "701-320-5117";
    private EditText mProductTextBox;
    private EditText mProductQuantityBox;
    private EditText mProductDescrBox;
    private Button mPlusBtn;
    private Button mMinusBtn;
    private InventoryDatabase mInventoryDb;
    private InventoryItem mCurrentProduct;
    private long mProductId;
    private String mUsername;
    private boolean mIsNewItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_item_detail);
        mProductQuantityBox = findViewById(R.id.productQuantityBox);
        mProductTextBox = findViewById(R.id.itemNameField);
        mProductDescrBox = findViewById(R.id.itemDescriptionField);
        mMinusBtn = findViewById(R.id.minusButton);
        mPlusBtn = findViewById(R.id.plusButton);

        // Database initialization
        mInventoryDb = InventoryDatabase.getInstance(getApplicationContext());

        Intent intent = getIntent();
        mUsername = intent.getStringExtra(EXTRA_USERNAME);
        mProductId = intent.getLongExtra(EXTRA_ITEM_ID, -1);
        if (mProductId >= 0) {
            // Existing item; update title and get reference to item from database
            setTitle(R.string.editItemTitle);
            mCurrentProduct = mInventoryDb.ProductInfo().getInventoryItem(mProductId);
        }
        else {
            // New item; update title and create new item
            setTitle(R.string.newProductName);
            mCurrentProduct = new InventoryItem("", 0, "", intent.getStringExtra(EXTRA_USERNAME));
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        mProductTextBox.setText(mCurrentProduct.getName());
        mProductQuantityBox.setText(String.valueOf(mCurrentProduct.getQuantity()));
        mProductDescrBox.setText(mCurrentProduct.getDescription());
    }

    public void onSaveClick(View view) {
        String enteredName = mProductTextBox.getText().toString().trim();
        long enteredQuantity = Long.parseLong(mProductQuantityBox.getText().toString().trim());
        String enteredDescription = mProductDescrBox.getText().toString().trim();

        if (mProductId == -1) {
            // Adds new product to the database
            InventoryItem newItem = new InventoryItem(
                    enteredName,
                    Long.parseLong(mProductQuantityBox.getText().toString().trim()),
                    mProductDescrBox.getText().toString().trim(),
                    mUsername);
            mInventoryDb.ProductInfo().insertInventoryItem(newItem);
        } else {

            if (enteredQuantity == 0 && mCurrentProduct.getQuantity() > 0) {
                sendSMS(SMS_NUMBER, getString(R.string.quantityZero, enteredName));
            }
            mCurrentProduct.setName(enteredName);
            mCurrentProduct.setQuantity(enteredQuantity);
            mCurrentProduct.setDescription(enteredDescription);
            mInventoryDb.ProductInfo().updateInventoryItem(mCurrentProduct);
        }
        finish();
    }

    public void onDeleteClick(View view) {
            // msg alert - SMS
        sendSMS(SMS_NUMBER, getString(R.string.productDeleted, mCurrentProduct.getName()));
        mInventoryDb.ProductInfo().deleteInventoryItem(mCurrentProduct);
        finish();
    }

    public void clickPlusSign(View view) {
        Long currentQuantity = Long.parseLong(mProductQuantityBox.getText().toString().trim());
        mProductQuantityBox.setText(Long.toString(currentQuantity + 1));
    }

    public void clickMinusSign(View view) {
        Long currentQuantity = Long.parseLong(mProductQuantityBox.getText().toString().trim());
        mProductQuantityBox.setText(Long.toString(currentQuantity - 1));
    }
    public void sendSMS(String mobileNumber, String message) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED)
        {
            try
            {
                SmsManager smsMgr = SmsManager.getDefault();
                smsMgr.sendTextMessage(mobileNumber, null, message, null, null);
                Toast.makeText(getApplicationContext(), getString(R.string.msg_sent),
                        Toast.LENGTH_LONG).show();
            }
            catch (Exception ErrVar)
            {
                Toast.makeText(getApplicationContext(),ErrVar.getMessage().toString(),
                        Toast.LENGTH_LONG).show();
                ErrVar.printStackTrace();
            }
        }
        else
        {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            {
                requestPermissions(new String[]{Manifest.permission.SEND_SMS}, 10);
            }
        }
    }
}