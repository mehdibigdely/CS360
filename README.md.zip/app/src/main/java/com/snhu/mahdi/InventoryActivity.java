package com.snhu.mahdi;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.github.mahdi.snhu.cs360.finalprojest.R;

import java.util.List;

public class InventoryActivity extends AppCompatActivity {

    public static final String EXTRA_USER_ID = "com.snhu.mahdi.EXTRA_USER_ID";

    private InventoryDatabase mInventoryDb;
    private List<InventoryItem> inventoryItems;
    private RecyclerView mRecyclerView;
    private InventoryItemAdapter mItemAdapter;
    private List<InventoryItem> mItems;
    private String mUsername;

    private InventoryItem mItemSelected;
    private int mSelectionPosition = RecyclerView.NO_POSITION;
    private ActionMode mActionMode = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        Intent intent = getIntent();
        mUsername = intent.getStringExtra(EXTRA_USER_ID);
        mInventoryDb = InventoryDatabase.getInstance(getApplicationContext());

        // RecyclerView and LayoutManager Initiation
        mRecyclerView = findViewById(R.id.itemRecyclerView);
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        // Avaialble products are shown
        mItemAdapter = new InventoryItemAdapter(loadItems(mUsername));
        mRecyclerView.setAdapter(mItemAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mItemAdapter = new InventoryItemAdapter(loadItems(mUsername));
        mRecyclerView.setAdapter(mItemAdapter);
    }

    private List<InventoryItem> loadItems(String user) {
        return mInventoryDb.ProductInfo().getInventoryItemsNewerFirst(user);
    }

    private class InventoryItemHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener {

        private InventoryItem mInventoryItem;
        private TextView mNameTextView;
        private TextView mQuantityField;

        public InventoryItemHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            itemView.setOnClickListener(this);
            mNameTextView = itemView.findViewById(R.id.itemNameTextView);
            mQuantityField = itemView.findViewById(R.id.productQuantityBox);
        }

        public void bind(InventoryItem inventoryItem, int position) {
            mInventoryItem = inventoryItem;
            mNameTextView.setText(mInventoryItem.getName());
            mQuantityField.setText(Long.toString(mInventoryItem.getQuantity()));

        }

        @Override
        public void onClick(View view) {
            Intent intent = new Intent(InventoryActivity.this, ItemDetailActivity.class);
            intent.putExtra(ItemDetailActivity.EXTRA_ITEM_ID, mInventoryItem.getId());
            intent.putExtra(ItemDetailActivity.EXTRA_USERNAME, mUsername);
            startActivity(intent);
        }
    }

    public void productAddBtn(View view) {
        Intent intent = new Intent(InventoryActivity.this, ItemDetailActivity.class);
        intent.putExtra(ItemDetailActivity.EXTRA_USERNAME, mUsername);
        startActivity(intent);
    }

    private class InventoryItemAdapter extends RecyclerView.Adapter<InventoryItemHolder> {

        private List<InventoryItem> mInventoryItemList;

        public InventoryItemAdapter(List<InventoryItem> inventoryItems) {
            mInventoryItemList = inventoryItems;
        }

        @Override
        public InventoryItemHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new InventoryItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(InventoryItemHolder holder, int position) {
            holder.bind(mInventoryItemList.get(position), position);
        }

        @Override
        public int getItemCount() {
            return mInventoryItemList.size();
        }

    }
}